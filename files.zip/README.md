# ✨ AirDraw

Draw in the air with your finger using your webcam — glowing neon trails follow your fingertip in real time.

## Deploy to Vercel (3 steps)

1. **Upload to GitHub**
   - Create a new repo on [github.com](https://github.com/new)
   - Upload `index.html` and `vercel.json`

2. **Deploy on Vercel**
   - Go to [vercel.com](https://vercel.com) → New Project
   - Import your GitHub repo
   - Click **Deploy** — no build settings needed!

3. **Done!** Share your live URL 🎉

## How to use

| Gesture | Action |
|---|---|
| ☝️ Index finger up | Draw |
| ✊ Fist / finger down | Lift pen (pause) |

- Pick neon colors from the toolbar
- Adjust brush size with the slider
- Hit **Save** to download your artwork as PNG

## Tech

- [MediaPipe Hands](https://developers.google.com/mediapipe/solutions/vision/hand_landmarker) — real-time hand tracking in the browser
- Pure HTML/CSS/JS — no build step needed
